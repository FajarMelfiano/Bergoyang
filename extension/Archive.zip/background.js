/**
 * Request Lagu — service worker extension.
 * Tugas: proxy API ke server (tanpa CORS) + login kode DJ.
 * Semua permintaan dari content script / popup lewat sini.
 *
 * Alamat server DIBAKUKAN (tidak ada kolom input di popup):
 * coba daftar server berikut sampai ada yang menjawab — server daring (Vercel)
 * dulu, server lokal sebagai cadangan. Urutan diingat selama service worker
 * hidup supaya panggilan berikutnya langsung ke server yang berhasil.
 */
'use strict';

const SERVERS = [
  'https://requestlagu.vercel.app', // ← URL proyek Vercel (dibakukan saat deploy)
  'http://localhost:3000',
];
const FETCH_TIMEOUT_MS = 4000;
const DEFAULTS = { djCode: '' };

let activeIdx = -1;          // indeks server yang terakhir berhasil
let tokenState = { server: '', token: '' }; // token DJ terikat ke satu server

async function config() {
  const saved = await chrome.storage.local.get(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...saved };
}

/** fetch dengan batas waktu agar server mati tidak menahan panggilan lama. */
function timedFetch(url, opts) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), FETCH_TIMEOUT_MS);
  return fetch(url, { ...opts, signal: ac.signal }).finally(() => clearTimeout(timer));
}

/** Urutan coba server: mulai dari yang terakhir berhasil, kalau belum ada → urut awal. */
function serverOrder() {
  const n = SERVERS.length;
  const base = activeIdx < 0 ? 0 : activeIdx;
  return Array.from({ length: n }, (_, i) => (base + i) % n);
}

async function login(server, code) {
  const res = await timedFetch(`${server}/api/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ code }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Login gagal (HTTP ${res.status})`);
  return data.token;
}

async function doFetch(server, path, method, body, tk) {
  try {
    const headers = {};
    if (tk) headers['x-dj-token'] = tk;
    if (body) headers['content-type'] = 'application/json';
    const res = await timedFetch(server + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    return { status: res.status, data };
  } catch {
    return { status: 0, data: { error: `Server tidak terjangkau (${server}).` } };
  }
}

async function handleApi({ path, method = 'GET', body }) {
  const { djCode } = await config();
  const failures = [];

  for (const idx of serverOrder()) {
    const server = SERVERS[idx];

    // Token DJ dihitung dari secret tiap server → wajib login per server.
    if (djCode && tokenState.server !== server) {
      try {
        tokenState = { server, token: await login(server, djCode) };
      } catch (err) {
        failures.push(`${server}: ${err.message}`);
        continue;
      }
    }

    let out = await doFetch(server, path, method, body, djCode ? tokenState.token : '');

    if (out.status === 0) {
      failures.push(`${server}: tidak terjangkau`);
      continue; // coba server berikutnya
    }

    // token kedaluwarsa / kode DJ berubah → coba login ulang sekali
    if (out.status === 401 && djCode) {
      try {
        tokenState = { server, token: await login(server, djCode) };
      } catch (err) {
        return { status: 401, data: { error: err.message } };
      }
      out = await doFetch(server, path, method, body, tokenState.token);
    }

    activeIdx = idx; // ingat server yang berhasil
    return out;
  }

  return {
    status: 0,
    data: { error: `Server tidak terjangkau. Sudah dicoba: ${SERVERS.join(' & ')} — ${failures.join('; ')}` },
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'api') {
    handleApi(msg).then(sendResponse);
    return true; // async
  }
  if (msg && msg.type === 'save') {
    chrome.storage.local.set(msg.values || {}).then(() => {
      tokenState = { server: '', token: '' }; // kode bisa berubah → login ulang berikutnya
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg && msg.type === 'config') {
    config().then((c) => sendResponse({ ...c, hasCode: Boolean(c.djCode) }));
    return true;
  }
  return false;
});
